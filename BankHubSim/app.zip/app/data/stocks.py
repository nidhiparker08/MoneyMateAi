STOCKS = [

("Reliance","RELIANCE"),

("TCS","TCS"),

("Infosys","INFY"),

("HDFC Bank","HDFCBANK"),

("ICICI Bank","ICICIBANK"),

("Asian Paints","ASIANPAINT"),

("ITC","ITC"),

("L&T","LT"),

("Tata Motors","TATAMOTORS")

]